
Cristian Rusu,
October, 2012

--------------------------------

This package contains proof-of-concept source code for the results presented in:
C. Rusu and B. Dumitrescu, Iterative Reweighted l1 Design of Sparse FIR Filters, Signal Processing, 92 (4), pp. 905-911, 2012.

Tested on Matlab R2012a.
For problems, bug reports, comments and other contact C. Rusu.

--------------------------------

Starting points:

test_1d - 1D filter design example.
test_2d - 2D filter design example.

--------------------------------

This package needs the CVX library (http://cvxr.com/cvx/) to be installed.

--------------------------------

Files:

filterByGreedySCR - Sparse filter design by Smallest Coeffiecient Rule.
filterByIRL1 - Sparse filter design by IRL1 (1D).
filterByM1N - Sparse filter design by M1N.
filterByMinError - Full 1D filter design.
getMinErrorNewFilter2d - Full 2D filter design.
newFilter2d - Sparse filter design by IRL1 (2D).
getnewC - Function used by newFilter2d to construct the design matrix.
