function [x t] = filterByGreedySCR(N, deltad, wp, ws, wo)
% Smallest Coefficient Rule (SCR) - remove the coefficient that is the
% smallest in magnitude.
%
% Reference: T. Baran, D. Wei, A.V. Oppenheim, Linear programming algorithms
% for sparse filter design, IEEE Transactions on Signal Processing 58
% (3) (2010) 1605�1617.

noDisplay = optimset('Display', 'off');

Kp = 1;
Ks = 1;
L = 15*N;
w = [0:L]*pi/L;
W = Kp*(w<=wp) + Ks*(w>=ws);

D = (w<=wo);
% remove points where W == 0
SN = 1e-8;
k = (W>SN);
w = w(k);
W = W(k);
D = D(k);
% construct matrices
M = (N-1)/2;
C = cos(w'*[0:M]);
V = 1./W';
Q = [C, -V; -C, -V];
b = [D'; -D'];
c = [zeros(M+1,1); 1];
[mq nq] = size(Q);
Q = bsxfun(@rdivide, Q, sqrt(sum(Q.^2)));

% every method solves the same optimization problem
Qorig = Q;
tobe0 = [];
step = 1;

% assume problem is feasible
deltar = 0;

oldx = [];

tic;
while (1)
    % solve linear program
    Q = Qorig(:, setdiff(1:nq, tobe0));
    c = [zeros(M+1-step+1,1); 1];
    [x f status] = linprog(c, Q, b, [], [], [], [], [], noDisplay);
    
    if (status~=1)
        break;
    end
    
    deltar = x(end);
    if (deltar>=deltad)
        break;
    end
    
    oldx = x;
    
    tobe0 = sort(tobe0);
    
    [minValue minPos] = min(abs(x(1:end-1)));
    for i = 1:length(tobe0)
        if (tobe0(i)<=minPos)
            minPos = minPos + 1;
        end
    end
    
    tobe0 = [tobe0 minPos];
    step = step + 1;
end

tobe0 = tobe0(1:end-1);

y = inf*ones(M+2, 1);

if (isempty(oldx))
    oldx = inf*ones(M+2, 1);
end

y(tobe0) = zeros(length(tobe0), 1);
index = 1;
for i=1:M+2
    if (y(i)==inf)
        y(i) = oldx(index);
        index = index + 1;
    end
end
x = y;
clear y;

t = toc;
