%% TEST 2D filter design
% Design sparse 2D filter - Table 5 in C. Rusu and B. Dumitrescu,
% Iterative Reweighted l1 Design of Sparse FIR Filters,
% Signal Processing, 92 (4), pp. 905-911, 2012.

%% clean-up
clear
clc
close all

%% check if CVX is installed
try
    run('cvx_setup');
catch err
    error('CVX problem.');
end

%% initialization 
% size of filter, odd
N = 29;
n = (N-1)/2;

%% parameters of the filter
wp = 0.6;
ws = 1;
L = 40;

miu = 0.001; % when N = {29, 17}
% miu = 0.00001; % when N = 23
% miu = 0.1 % when N = 11

%% imposed error
deltaimposed = 0.000984; % when N = 29
% deltaimposed = 0.00373; % when N = 23
% deltaimposed = 0.00539; % when N=17
% deltaimposed = 0.08077; % when N=11


%% get smallest error with full filter
minerror = getMinErrorNewFilter2d(N, wp, ws, L);
diff = deltaimposed - minerror;
if (diff < 0)
    error('Imposed error cannot be achieved.');
end
% indices removed from the support of the solution
notSupport = [];
% maximum number of greedy iterations
maxGreedy = 5;

%% IRL1Gx3
tic
[H, HvalDB, error, notSupport] = newFilter2d(N, wp, ws, L, miu, minerror + diff/4, notSupport, maxGreedy);
[H, HvalDB, error, notSupport] = newFilter2d(N, wp, ws, L, miu, minerror + diff/2, notSupport, maxGreedy);
[H, HvalDB, error, notSupport] = newFilter2d(N, wp, ws, L, miu, deltaimposed, notSupport, inf);
toc

%% plot
[xplot, yplot] = meshgrid(linspace(-1,1,40));
mesh(xplot, yplot, HvalDB);
xlabel('Frequency'), ylabel('Frequency'), zlabel('Magnitude');
