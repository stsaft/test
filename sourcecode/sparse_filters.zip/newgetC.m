function [c wayC] = newgetC(n, L, w)
%% build C matrix of design

c = zeros(L*L, (n+1)^2);
wayC = zeros(L*L, 2);

line = 0;
for wi = w
    for wj = w
        
        line = line + 1;
        wayC(line, 1) = wi;
        wayC(line, 2) = wj;
        column = 1;
        
        c(line, column) = 1;
        
        for k2=1:n
            column = column + 1;
            c(line, column) = cos(wj*k2);
        end
        
        for k1=1:n
            column = column + 1;
            c(line, column) = cos(wi*k1);
        end
        
        
        for k1=1:n
            for k2=1:n
                column = column + 1;
                c(line, column) = cos(wi*k1)*cos(wj*k2);
            end
        end
        
    end
end
