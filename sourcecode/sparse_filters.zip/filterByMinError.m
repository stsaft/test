function [delta] = filterByMinError(N, wp, ws, wo)
% compute a sparse filter of length M + 1, where M = (N-1)/2
% such that the error < deltad using IRL1, trucated and full verions
Kp = 1;
Ks = 1;
L = round(5.2*N)-3;
w = [0:L]*pi/L;
W = Kp*(w<=wp) + Ks*(w>=ws);

D = double(w<=wo);
Dold = double(w<=wo);
indices = D==0;
D(indices) = 0.0316;

% remove points where W == 0
SN = 1e-8;
k = (W>SN);
w = w(k);
W = W(k);
D = D(k);
Dold = Dold(k);

% construct matrices
M = (N-1)/2;
C = cos(w'*[0:M]);
V = 1./W';
Vold = V;
Vold(indices) = 0;
Vold = Vold(k);
Q = [C, -Vold; -C, -Vold];
b = [D'; -Dold'];
c = [zeros(M+1,1); 1];
[mq nq] = size(Q);


cvx_quiet(true);
cvx_begin
    variable y(nq);
    minimize(c'*y);
    subject to
        Q*y <= b;
cvx_end

delta = y(end);


a = y(1:end-1);
del = y(end);
h = [a(nq-1:-1:2); 2*a(1); a(2:nq-1)]/2;
freqz(h);
