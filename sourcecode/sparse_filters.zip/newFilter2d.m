function [H, HvalDB, error, notSupport] = newFilter2d(N, wp, ws, L, miu, deltaimposed, notSupport, maxGreedy)
%% IRL1 filter design

%% degrees of freedom
n = (N-1)/2;

%% build matrices
F = (0:1/L:(L-1)/L);
f1 = repmat(F, L, 1);
f2 = f1';

dp = find(abs(f1)+abs(f2) < wp);
Hd = zeros(L);
Hd(dp) = ones(size(dp));

w = (0:L-1)*pi/(L-1);

[C wayC] = newgetC(n, L, w);
[mC nC] = size(C);
toeliminate = [];
for i=1:mC
    if ( (wayC(i,1) + wayC(i,2)) > (wp*pi)) && ( (wayC(i,1) + wayC(i,2)) < (ws*pi))
        toeliminate = [toeliminate i];
    end
end
C(toeliminate, :) = [];

line = 0;
newD = zeros(L*L, 1);
wayD = zeros(L*L, 2);
for i=1:L
    for j=1:L
        line = line+1;
        newD(line) = Hd(i, j);
        wayD(line, 1) = w(i);
        wayD(line, 2) = w(j);
    end
end
newD(toeliminate, :) = [];
D = [newD; -newD];

delta = ones(L*L-length(toeliminate), 1);
Q = [C, -delta;-C, -delta];
[mQ nQ] = size(Q);
c = [zeros(nQ-1, 1); 1];

clear C delta

%% IRL1
steps = 15;
eps = 10e-6;

Q = [Q; zeros(1, nQ-1) 1];
D = [D; deltaimposed];
[mQ nQ] = size(Q);
W = eye(nQ);
W(nQ, nQ) = 0;
cvx_quiet(true);
w = [];

for index = 1:steps
    tic
    cvx_solver sdpt3
    
    if (isempty(notSupport))
       cvx_begin
            cvx_precision default
            variable x(nQ);
            minimize(c'*x + miu*norm(W*x, 1));
            subject to
                Q*x <= D;
        cvx_end
    else
        cvx_begin
            cvx_precision default
            variable x(nQ);
            minimize(c'*x + miu*norm(W*x, 1));
            subject to
                Q*x <= D;
                x(notSupport) == zeros(length(notSupport), 1);
        cvx_end
    end
    
    if (~strcmp(cvx_status, 'Solved') && ~strcmp(cvx_status, 'Inaccurate/Solved'))
        break;
    end
    
%     if (index>2)
        notSupport = find(abs(x(1:nQ-1))<=(2.7*10e-6));
%     end
    
    W = sparse(diag([0; 1./(abs(x(2:nQ-1)) + eps); 0]));
    
    % additional weigths of H33 coeff.
    for i = 2+2*n:nQ-1
        W(i,i) = W(i,i)*4;
    end
    
    w(index) = norm(diag(W), 2);
    
    % extra stop condition
    if (index > 3 && abs(w(index)-w(index-1))<0.01)
        break;
    end
    toc
end


%% solve again to minimize error
if (~isempty(notSupport))
    cvx_solver sedumi
    cvx_begin
        variable x(nQ);
        minimize(c'*x);
        subject to
            Q*x <= D;
            x(notSupport) == zeros(length(notSupport), 1);
    cvx_end
else
    cvx_solver sedumi
    cvx_begin
        variable x(nQ);
        minimize(c'*x);
        subject to
            Q*x <= D;
    cvx_end    
end

minerror = x(end);

%% Greedy iterations
c = [zeros(nQ-1, 1); 1];
oldx = x;
greedy = 0;

while(greedy<maxGreedy)
    x(notSupport) = inf*ones(length(notSupport), 1);
    [minvalue minindex] = min(abs(x(1:end-1)));
    notSupport = [notSupport; minindex];
    
    cvx_begin
        variable x(nQ);
        minimize(c'*x);
        subject to
            Q*x <= D;
            x(notSupport) == zeros(length(notSupport), 1);
    cvx_end
    
    if (~strcmp(cvx_status, 'Solved') && ~strcmp(cvx_status, 'Inaccurate/Solved'))
        notSupport = notSupport(1:end-1);
        x = oldx;
        break;
    end
    
    oldx = x;
    greedy = greedy + 1;
end

%% extract filter
error = x(end);

H33 = reshape(x(2+2*n:end-1), n, n)/4;
h22 = x(1,1);
h23t = x(n+2:2*n+1)'/2;
h32 = x(2:n+1)/2;

H11 = flipud(fliplr(H33));
H13 = flipud(H33); H31 = fliplr(H33);
h12 = flipud(h32); h21t = (fliplr(h23t));

H = [H11 h12 H13; h21t h22 h23t; H31 h32 H33];
% freqz2(H);
zerocoeff = length(find(abs(H)==0));
nonzerocoeff = N*N - zerocoeff
[Hval] = freqz2(H, L, L);
HvalDB = 20*log10(abs(Hval));
