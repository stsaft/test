%% TEST 1D filter design
% Design sparse 1D filter - C. Rusu and B. Dumitrescu,
% Iterative Reweighted l1 Design of Sparse FIR Filters,
% Signal Processing, 92 (4), pp. 905-911, 2012.

%% clean-up
clear
clc
close all

%% check if CVX is installed
try
    run('cvx_setup');
catch err
    error('CVX problem.');
end

%% Design specifications
wp = 0.26*pi;
ws = 0.34*pi;
wo = 0.30*pi;

%% Dimensions
N = 51;
mindelta = filterByMinError(N, wp, ws, wo);

%% imposed error
deltad = 0.5;
diff = deltad - mindelta;
if (diff < 0)
    error('Imposed error cannot be achieved.');
end
notSupport = [];

%% IRL1Gx3
[xFullIter tFullIter1 kfull notSupport] = filterByIRL1(N, mindelta + diff/4, wp, ws, wo, notSupport);
[xFullIter tFullIter2 kfull notSupport] = filterByIRL1(N, mindelta + diff/2, wp, ws, wo, notSupport);
[xFullIter tFullIter3 kfull notSupport] = filterByIRL1(N, mindelta + diff/1, wp, ws, wo, notSupport);
tFullIter = tFullIter1+tFullIter2+tFullIter3;

%% M1N method
tic; [xM1N tM1N kM1N notSupport] = filterByM1N(N, deltad, wp, ws, wo, notSupport); tM1N = toc;

%% SCR method
tic; [xSCR tSCR] = filterByGreedySCR(N, deltad, wp, ws, wo); tSCR = toc;

sFullIter = length(find(abs(xFullIter)==0));
sSCR = length(find(abs(xSCR)==0));
sM1N = length(find(abs(xM1N)==0));
