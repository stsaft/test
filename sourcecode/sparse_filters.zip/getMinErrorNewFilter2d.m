function [minerror] = getMinErrorNewFilter2d(N, wp, ws, L)
%% degrees of freedom
n = (N-1)/2;

%% build matrices
F = (0:1/L:(L-1)/L);
f1 = repmat(F, L, 1);
f2 = f1';

dp = find(abs(f1)+abs(f2) < wp);
Hd = zeros(L);
Hd(dp) = ones(size(dp));

w = (0:L-1)*pi/(L-1);

[C wayC] = newgetC(n, L, w);
[mC nC] = size(C);
toeliminate = [];
for i=1:mC
    if ( (wayC(i,1) + wayC(i,2)) > (wp*pi)) && ( (wayC(i,1) + wayC(i,2)) < (ws*pi))
        toeliminate = [toeliminate i];
    end
end
C(toeliminate, :) = [];

line = 0;
newD = zeros(L*L, 1);
wayD = zeros(L*L, 2);
for i=1:L
    for j=1:L
        line = line+1;
        newD(line) = Hd(i, j);
        wayD(line, 1) = w(i);
        wayD(line, 2) = w(j);
    end
end
newD(toeliminate, :) = [];
D = [newD; -newD];

delta = ones(L*L-length(toeliminate), 1);
Q = [C, -delta;-C, -delta];
[mQ nQ] = size(Q);
c = [zeros(nQ-1, 1); 1];

clear C delta

%% find minimum error with this order N
cvx_solver sdpt3
cvx_quiet true
cvx_begin
    variable x(nQ);
    minimize(c'*x);
    subject to
        Q*x <= D;
cvx_end
minerror = x(end);
