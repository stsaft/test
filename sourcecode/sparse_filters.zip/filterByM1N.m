function [xM1N tM1N kM1N notSupport] = filterByM1N(N, deltad, wp, ws, wo, notSupport)
% Minimum 1-norm design
%
% Reference: T. Baran, D. Wei, A.V. Oppenheim, Linear programming algorithms
% for sparse filter design, IEEE Transactions on Signal Processing 58
% (3) (2010) 1605�1617.

kM1N = 0;
noDisplay = optimset('Display', 'off');

Kp = 1;
Ks = 1;
L = 15*N;
w = [0:L]*pi/L;
W = Kp*(w<=wp) + Ks*(w>=ws);

D = (w<=wo);
% remove points where W == 0
SN = 1e-8;
k = (W>SN);
w = w(k);
W = W(k);
D = D(k);

% construct matrices
M = (N-1)/2;
C = cos(w'*[0:M]);
V = 1./W';
Q = [C, -V; -C, -V];
b = [D'; -D'];
[mq nq] = size(Q);
Q = bsxfun(@rdivide, Q, sqrt(sum(Q.^2)));

Qorig = [Q; zeros(1,nq-1) 1];
borig = [b; deltad];
del = 0;
tocut = 0;

cvx_begin
    variable y(nq);
    minimize(norm(y, 1));
    subject to
        Qorig*y <= borig;
cvx_end
del = y(end);
yold = [];

%% full RWL1
tic
while (del<=deltad)
        yold = y;
        tocut = tocut + 1;
        [values indexes] = sort(abs(y(1:end-1)));
        
        notSupport = indexes(1:tocut);
        
        cvx_begin
%             cvx_precision low
            variable y(nq);
            minimize(norm(y(1:end-1), 1));
            subject to
                Qorig*y <= borig;
                y(notSupport) == zeros(length(notSupport), 1)
        cvx_end
        
        del = y(end);
end



tM1N = toc;

% a = y(1:end-1);
% del = y(end);
% h = [a(nq-1:-1:2); 2*a(1); a(2:nq-1)]/2;

xM1N = yold;
