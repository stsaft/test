function [xFullIter tFullIter kfull notSupport] = filterByIRL1(N, deltad, wp, ws, wo, notSupport)
% Compute a sparse filter of length M + 1, where M = (N-1)/2
% such that the error < deltad using IRL1, trucated and full verions

noDisplay = optimset('Display', 'off');

Kp = 1;
Ks = 1;
L = 15*N;
w = [0:L]*pi/L;
W = Kp*(w<=wp) + Ks*(w>=ws);

D = (w<=wo);
% remove points where W == 0
SN = 1e-8;
k = (W>SN);
w = w(k);
W = W(k);
D = D(k);

%% construct matrices
M = (N-1)/2;
C = cos(w'*[0:M]);
V = 1./W';
Q = [C, -V; -C, -V];
b = [D'; -D'];
[mq nq] = size(Q);
Q = bsxfun(@rdivide, Q, sqrt(sum(Q.^2)));

Qorig = [Q; zeros(1,nq-1) 1];
borig = [b; deltad];

%% full RWL1
tic
steps = 10;
[mq nq] = size(Qorig);
W = eye(nq);
W(nq,nq) = 0;
eps = 10e-6;
cvx_quiet(true);
kfull = 0;
maxSparse = 0;
miu = 1;
c = [zeros(1, nq-1) 1];

cvx_solver sdpt3

for index = 1:steps
    if (~isempty(notSupport))
        cvx_begin quiet
            cvx_precision low
            variable y(nq);
            minimize(c*y +  miu*norm(W*y, 1));
            subject to
                Qorig*y <= borig;
                y(notSupport) == zeros(length(notSupport), 1)
        cvx_end
    else
        cvx_begin quiet
            cvx_precision low
            variable y(nq);
            minimize(c*y + miu*norm(W*y, 1));
            subject to
                Qorig*y <= borig;
        cvx_end
    end
    
    
    kfull = kfull + cvx_slvitr;
    
    if (strcmp(cvx_status, 'Infeasible') == 1)
        break;
    end
    
    W = sparse(diag([1./(abs(y(1:nq-1)) + eps); 0]));
    notSupport = find(abs(y(1:nq-1))<10e-6);

    if (length(notSupport)>maxSparse)
        maxSparse = length(notSupport);
    end
end

%% Polishing ...
if (~isempty(notSupport))
    cvx_begin
        cvx_precision low
        variable y(nq);
        minimize(c*y);
        subject to
            Qorig*y <= borig;
            y(notSupport) == zeros(length(notSupport), 1)
    cvx_end
end

%% Greedy iterations
oldy = y;
c = [zeros(1, nq-1) 1];
while(1)
    y(notSupport) = inf*ones(length(notSupport), 1);
    [minvalue minindex] = min(abs(y(1:end-1)));
    notSupport = [notSupport; minindex];
    
    cvx_begin
        variable y(nq);
        minimize(c*y);
        subject to
            Qorig*y <= borig;
            y(notSupport) == zeros(length(notSupport), 1);
    cvx_end
    
    if (~strcmp(cvx_status, 'Solved') && ~strcmp(cvx_status, 'Inaccurate/Solved'))
        notSupport = notSupport(1:end-1);
        y = oldy;
        break;
    end
    
    oldy = y;
end

tFullIter = toc;

xFullIter = y;
