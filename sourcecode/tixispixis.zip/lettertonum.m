function [in]=lettertonum(in);
% This function accepts a DNA sequence and returns 
% a matrix of integers according to the following
% conversion:
%
%		A --> 0
%		C --> 1
%		T --> 2
%		G --> 3
%
%-------------------------------------------------
%|   Version:    1.0                             |
%|   Date:       2/28/2003                       |
%|   Author:     Sotirios A. Tsaftaris           |
%|   e-mail:     s-tsaftaris@northwestern.edu    |
%-------------------------------------------------


in(in=='A')=0;
in(in=='C')=1;
in(in=='T')=2;
in(in=='G')=3;

in=double(in);