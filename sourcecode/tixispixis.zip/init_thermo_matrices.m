function [W]=init_thermo_matrices(W)
%initialize the deltaH and deltaS for matched pairs
%
% W matrix has dimensions 4x4x4x4x2
% Corresponds to dimers XY/xy
% Last dimension is 1 for dH and 2 for dS
%
% Format:
% 		
%		5'-XY-3'
%		   ||
%		3'-xy-5'
%
%	The dimer XY/xy is in W(X,Y,x,y,:)=[dH dS]
%														  
%
% Examples:
% 		The dimer AT/TA is in W(A,T,T,A,:)=[-7.2 -20.4]
%														  |     |
%														 dH	 dS
%
% Thermodynamic parameters taken from:
% 		Allawi & Santalucia Biochemistry 36, 1997.
%
%-------------------------------------------------
%|   Version:    1.0                             |
%|   Date:       2/24/2003                       |
%|   Author:     Sotirios A. Tsaftaris           |
%|   e-mail:     s-tsaftaris@northwestern.edu    |
%-------------------------------------------------

% this arrangement is in accordance with the notation used for getting complementarity

A=1;
C=2;
T=3;
G=4;

W(A,A,T,T,:)=[-7.9 -22.25];
W(A,C,T,G,:)=[-8.4 -22.435];
W(A,T,T,A,:)=[-7.2 -20.38];
W(A,G,T,C,:)=[-7.8 -21.025];

W(C,A,G,T,:)=[-8.5 -22.725];
W(C,C,G,G,:)=[-8.0 -19.86];
W(C,T,G,A,:)=[-7.8 -21.025];
W(C,G,G,C,:)=[-10.6 -27.18];

W(T,A,A,T,:)=[-7.2 -21.32];
W(T,C,A,G,:)=[-8.2 -22.245];
W(T,T,A,A,:)=[-7.9 -22.25];
W(T,G,A,C,:)=[-8.5 -22.725];

W(G,A,C,T,:)=[-8.2 -22.245];
W(G,C,C,G,:)=[-9.8 -24.4];
W(G,T,C,A,:)=[-8.4 -22.435];
W(G,G,C,C,:)=[-8.0 -19.86];

W=init_thermo_matrices_mismatch(W);



%-----------------------------------------------------

function [W]=init_thermo_matrices_mismatch(W)
%	Initialize single mismatched pairs
%
%	Parameters taken from :
%
%	1)	Allawi  and Santalucia (1997) Biochemistry 36, 10581 
%	2)	Allawi  and Santalucia (1998) Biochemistry 37, 2170 
%	3)	Allawi  and Santalucia (1997) Nucleic Acids Res.26, 2694 
%	4)	Allawi  and Santalucia (1998) Biochemistry 37, 9435 
%	5)	Peyret et al. (1999) Biochemistry 38, 3468-3477. 
%
%-------------------------------------------------
%|   Version:    1.0                             |
%|   Date:       2/24/2003                       |
%|   Author:     Sotirios A. Tsaftaris           |
%|   e-mail:     s-tsaftaris@northwestern.edu    |
%-------------------------------------------------

% G.T mismatches first
A=1;
C=2;
T=3;
G=4;


W(A,G,T,T,:)=[+1.0 +0.9];
W(T,T,G,A,:)=[+1.0 +0.9];
W(A,T,T,G,:)=[-2.5 -8.3];
W(G,T,T,A,:)=[-2.5 -8.3];

W(C,G,G,T,:)=[-4.1 -11.7];
W(T,G,G,C,:)=[-4.1 -11.7];
W(C,T,G,G,:)=[-2.8 -8.0];
W(G,G,T,C,:)=[-2.8 -8.0];

W(G,T,C,G,:)=[-4.4 -12.3];
W(G,C,T,G,:)=[-4.4 -12.3];
W(G,G,C,T,:)=[+3.3 +10.4];
W(T,C,G,G,:)=[+3.3 +10.4];

W(T,T,A,G,:)=[-1.3 -5.3];
W(G,A,T,T,:)=[-1.3 -5.3];
W(T,G,A,T,:)=[-0.1 -1.7];
W(T,A,G,T,:)=[-0.1 -1.7];


% A.A mismatches

W(A,A,T,A,:)=[1.2 1.7];
W(A,T,A,A,:)=[1.2 1.7];

W(C,A,G,A,:)=[-0.9 -4.2];
W(A,G,A,C,:)=[-0.9 -4.2];

W(G,A,C,A,:)=[-2.9 -9.8];
W(A,C,A,G,:)=[-2.9 -9.8];

W(T,A,A,A,:)=[4.7 12.9];
W(A,A,A,T,:)=[4.7 12.9];

% C.C mismatches

W(A,C,T,C,:)=[0.0 -4.4];
W(C,T,C,A,:)=[0.0 -4.4];

W(C,C,G,C,:)=[-1.5 -7.2];
W(C,G,C,C,:)=[-1.5 -7.2];

W(G,C,C,C,:)=[3.6 8.9];
W(C,C,C,G,:)=[3.6 8.9];

W(T,C,A,C,:)=[6.1 16.28];
W(C,A,C,T,:)=[6.1 16.28];

% G.G mismatches

W(A,G,T,G,:)=[-3.1 -9.5];
W(G,T,G,A,:)=[-3.1 -9.5];

W(C,G,G,G,:)=[-4.9 -15.3];
W(G,G,G,C,:)=[-4.9 -15.3];

W(G,G,C,G,:)=[-6.0 -15.8];
W(G,C,G,G,:)=[-6.0 -15.8];

W(T,G,A,G,:)=[1.6 3.6];
W(G,A,G,T,:)=[1.6 3.6];

% T.T mismatches

W(A,T,T,T,:)=[-2.7 -10.8];
W(T,T,T,A,:)=[-2.7 -10.8];

W(C,T,G,T,:)=[-5.0 -15.8];
W(T,G,T,C,:)=[-5.0 -15.8];

W(G,T,C,T,:)=[-2.2 -8.4];
W(T,C,T,G,:)=[-2.2 -8.4];

W(T,T,A,T,:)=[0.2 -1.5];
W(T,A,T,T,:)=[0.2 -1.5];

% G.A mismatches 

W(A,G,T,A,:)=[-0.7 -2.3];
W(A,T,G,A,:)=[-0.7 -2.3];
W(A,A,T,G,:)=[-0.6 -2.3];
W(G,T,A,A,:)=[-0.6 -2.3];

W(C,A,G,G,:)=[-0.7 -2.3];
W(G,G,A,C,:)=[-0.7 -2.3];
W(C,G,G,A,:)=[-4.0 -13.2];
W(A,G,G,C,:)=[-4.0 -13.2];

W(G,A,C,G,:)=[-0.6 -1.0];
W(G,C,A,G,:)=[-0.6 -1.0];
W(G,G,C,A,:)=[0.5 +3.2];
W(A,C,G,G,:)=[0.5 +3.2];

W(T,A,A,G,:)=[0.7 0.7];
W(G,A,A,T,:)=[0.7 0.7];
W(T,G,A,A,:)=[3.0 7.4];
W(A,A,G,T,:)=[3.0 7.4];

% C.T mismatches 

W(A,C,T,T,:)=[0.7 +0.2];
W(T,T,C,A,:)=[0.7 +0.2];
W(A,T,T,C,:)=[-1.2 -6.2];
W(C,T,T,A,:)=[-1.2 -6.2];

W(C,C,G,T,:)=[-0.8 -4.5];
W(T,G,C,C,:)=[-0.8 -4.5];
W(C,T,G,C,:)=[-1.5 -6.1];
W(C,G,T,C,:)=[-1.5 -6.1];

W(G,C,C,T,:)=[2.3 5.4];
W(T,C,C,G,:)=[2.3 5.4];
W(G,T,C,C,:)=[5.2 +13.5];
W(C,C,T,G,:)=[5.2 +13.5];

W(T,C,A,T,:)=[1.2 0.7];
W(T,A,C,T,:)=[1.2 0.7];
W(T,T,A,C,:)=[1.0 0.7];
W(C,A,T,T,:)=[1.0 0.7];

% A.C mismatches 

W(A,A,T,C,:)=[2.3 4.6];
W(C,T,A,A,:)=[2.3 4.6];
W(A,C,T,A,:)=[5.3 14.6];
W(A,T,C,A,:)=[5.3 14.6];

W(C,A,G,C,:)=[1.9 3.7];
W(C,G,A,C,:)=[1.9 3.7];
W(C,C,G,A,:)=[0.6 -0.6];
W(A,G,C,C,:)=[0.6 -0.6];

W(G,A,C,C,:)=[5.2 14.2];
W(C,C,A,G,:)=[5.2 14.2];
W(G,C,C,A,:)=[-0.7 -3.8];
W(A,C,C,G,:)=[-0.7 -3.8];

W(T,A,A,C,:)=[3.4 8.0];
W(C,A,A,T,:)=[3.4 8.0];
W(T,C,A,A,:)=[7.6 20.2];
W(A,A,C,T,:)=[7.6 20.2];




