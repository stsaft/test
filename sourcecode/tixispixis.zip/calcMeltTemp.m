function [Tm,deltaH,deltaS]=calcMeltTemp(template,oligo,dH,dS)
%		Calculate melting temperature of a duplex
%
%USAGE:
%    	[Tm]=new_calc_temp(template,oligo,dH,dS)
%    	Will calculate the melting temperature between the 
%    	template and the oligo give the thermodynamic parameters dH and dS.
%
% FORMAT OF THE INPUT:
%	  	Template and oligo are integer sequences with the following mapping:
%		A <-> 0
%		C <-> 1
%		T <-> 2
%		G <-> 3
%
%  Referenced Function tree:
%		function [W]=init_thermo_matrices(W)
%			|
%			+--> function [W]=init_thermo_matrices_mismatch(W)
%
%-------------------------------------------------
%|   Version:    1.2                             |
%|   Date:       3/03/2003                       |
%|   Author:     Sotirios A. Tsaftaris           |
%|   e-mail:     s-tsaftaris@northwestern.edu    |
%-------------------------------------------------


% 	Boltzmann's constant in kcal/(mol*K)  
boltzR=0.001987;
%  Molar salt concentration  [Na+]	NOTE: Now hardcoded later maybe available as input   
molsalt=1;
%  Molar oligo concentration [C] 	NOTE: Now hardcoded later maybe available as input
molC=2.0e-4;

debug=0; % Set to 1 for degugging information set to 0 for none

init(1,:)=[2.3 4.095]; 	% A.T initialization
init(2,:)=[0.1 -2.84];	% C.G initialization
init(3,:)=[2.3 4.095]; 	% T.A initialization
init(4,:)=[0.1 -2.84];	% G.C initialization

% set the necessary flags.
danglestart = 0;
dangleend = 0; 
effstart = 1;

effend=max(size(template));


match=bitxor(template,oligo);
    
while ((match(effstart) ~=2) | ((match(effstart) ==2) & ((match(effstart+1) ~=2)))) & (effstart<effend-1)
    danglestart = 1;
    effstart = effstart + 1;
end


while ((match(effend) ~=2) | ((match(effend) ==2) & ((match(effend-1) ~=2)))) & (effstart<effend)
    dangleend = 1;
    effend = effend - 1;
 end
 
if (effstart >= effend) 
    Tm=-100;
    return;
 end
 

top=template+1;
bottom=oligo+1;

if debug==1
   disp(sprintf('dangelstart=%d dangleend=%d effstart=%d effend=%d\n',danglestart,dangleend,effstart,effend))
end


deltaH0=init(top(effstart),1)+init(top(effend),1);
deltaS0=init(top(effstart),2)+init(top(effend),2);
if debug==1
   disp(sprintf('Initial   	Position %d dH=%f dS=%f\n',0,deltaH0,deltaS0))
end


for k = effstart:effend-1
   
   %	Perfect match case.
   if (match(k)==2) & (match(k+1)==2)
      
      
      deltaH0=deltaH0+dH(top(k),top(k+1),bottom(k),bottom(k+1));
      deltaS0=deltaS0+dS(top(k),top(k+1),bottom(k),bottom(k+1));      
      if debug==1
         disp(sprintf('In  Match  	Position %d dH=%f dS=%f\n',k,deltaH0,deltaS0))
      end
      

   elseif (match(k)~=2) & (match(k+1)~=2)
      %	nothing here for now. May put loop parameters
     	%  disp('in loop')
   elseif (match(k)==2) & (match(k+1)~=2) & (match(k+2)==2) 
      %	Single mismatch case. The way the algorithm is designed 
      %	the last base pair computed top(effend).bottom(effend) is always matched.
      
      deltaH0=deltaH0+dH(top(k),top(k+1),bottom(k),bottom(k+1));
      deltaS0=deltaS0+dS(top(k),top(k+1),bottom(k),bottom(k+1));
      if debug==1
         disp(sprintf('In  single 	Position %d dH=%f dS=%f\n',k,deltaH0,deltaS0))
      end
      

      k=k+1;
     % this is how we treat single mismatches. After identified they are processed immediately.
     
     deltaH0=deltaH0+dH(top(k),top(k+1),bottom(k),bottom(k+1));
     deltaS0=deltaS0+dS(top(k),top(k+1),bottom(k),bottom(k+1));
     if debug==1
        disp(sprintf('After single	Position %d dH=%f dS=%f\n',k,deltaH0,deltaS0))
     end
     
   end
end


deltaH0 =deltaH0 - 8.0 * (danglestart + dangleend);
deltaS0 =deltaS0 - 23.48 * (danglestart + dangleend);

deltaS0=0.001*deltaS0;
if debug==1
   disp(sprintf('Final values: dH=%f dS=%f\n',deltaH0,deltaS0))
end


if molsalt==1
    Tm = (deltaH0) / (deltaS0 + (boltzR * log(molC/4))) - 273.15;
else
    Tm = (deltaH0) / (deltaS0 + (boltzR * log(molC/4))) + 16.6 * log10(molsalt / (1 + 0.7 * molsalt)) - 269.32; 
end

deltaH=deltaH0;
deltaS=deltaS0;