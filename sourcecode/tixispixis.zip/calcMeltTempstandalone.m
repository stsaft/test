function [Tm,deltaH,deltaS]=calcMeltTempstandalone(varargin);
% this function calculates the Melting Temperature of a duplex
%
%USAGE:
% 1) 	[Tm,deltaH,deltaS]=calcMeltTempstandalone(template)
%    	Will calculate the melting temperature (dH and dS) between the 
%    	template and the watson crick complement of the template.
% 2) 	[Tm,deltaH,deltaS]=calcMeltTempstandalone(template,oligo)
%    	Will calculate the melting temperature between the 
%    	template and the oligo.
%
% The function will automatically detect the format of the input.
% If the format is in letters {A,T,G,C} a conversion to numbers will 
% take place first.
%
% EXAMPLES:  
%       [Tm,deltaH,deltaS]=calcMeltTempstandalone('AAATAAA','CTCATTT');
%       [Tm,deltaH,deltaS]=calcMeltTempstandalone('AAATAAA');
%
%
% NOTES: Currently it does not work well if the sequence length is really small (~4) 
%        and has many mismatches
%
%
%
% Referenced Function tree:
%		function [Tm]=calcMeltTemp(template,oligo,dH,dS);
%			|
%			+--> function [template]=lettertonum(template)
%			+--> function [W]=init_thermo_matrices(W)
%					|
%					+--> function [W]=init_thermo_matrices_mismatch(W)
%
%-------------------------------------------------
%|   Version:    1.1                             |
%|   Date:       3/5/2003                        |
%|   Author:     Sotirios A. Tsaftaris           |
%|   e-mail:     s-tsaftaris@northwestern.edu    |
%-------------------------------------------------


 %process input:
 switch (nargin)
 case 0
    disp('ERROR: Few arguments')
    return;
 case 1
    % only one input. Looking for Tm between a template and its WC complement
    template=varargin{1};
    if ischar(template)
       % if is in character format make it integers
       template=lettertonum(template);
    end
    
    % this performs WATSON-CRICK inversion. Oligo is the WC complement of the template
    oligo=bitxor(template,2*ones(size(template)));
 case 2
    template=varargin{1};
    oligo=varargin{2};
    if ischar(template)
       % if is in character format make it integers
       template=lettertonum(template);
    end
    if ischar(oligo)
       % if is in character format make it integers
       oligo=lettertonum(oligo);
    end

 end
 
 
W=zeros(4,4,4,4,2);		% The matrix the carries all the dS and dH for all possible dimers

W=init_thermo_matrices(W);

dH=W(:,:,:,:,1);

dS=W(:,:,:,:,2);

[Tm,deltaH,deltaS]=calcMeltTemp(template,oligo,dH,dS);
