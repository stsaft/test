
Cristian Rusu,
October, 2013

--------------------------------

This package contains proof-of-concept source code for the results presented in:
C. Rusu, Design of Incoherent Frames via Convex Optimization , IEEE Signal Processing Letters, 20 (7), pp. 673-676, 2013.

Tested on Matlab R2012a.
For problems, bug reports, comments and other contact C. Rusu.

--------------------------------

Starting points:

test - IDCO frame design example.

--------------------------------

This package needs the CVX library (http://cvxr.com/cvx/) to be installed.

--------------------------------
