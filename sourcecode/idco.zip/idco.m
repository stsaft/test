function [bestA minmc time mcs] = idco(A, K)
%IDCO Iterative Decorrelation by Convex Optimizatio algorithm - 
% A proof of concept implementation of the IDCO algorithm.
%
% [bestA minmc time mcs] = IDCO(A, K)
%
% Input:
%   A - initial frame
%   K - number of iterations
%
% Output:
%   bestA - output incoherent frame
%   minmc - minimum mutual coherence achieved
%   time - execution time
%   mcs - evolution of mutual coherence
%
%  Reference: Rusu, Cristian Design of Incoherent Frames via 
%     Convex Optimization. IEEE Signal Processing Letters,
%     20(7):673-676, 2013.

% start timer
tic;

%% setup
[n m] = size(A);

A = bsxfun(@rdivide, A, sqrt(sum(A.^2)));
mcs = max(max(abs(A'*A) - eye(m)));
bestA = A;
minmc = mcs;

mcs = [mcs max(max(abs(A'*A) - eye(m)))];

% mask
W = ones(m) - eye(m);

% norm of constraints, see line 78
nrmCnst = 1;
% nrmCnst = 2;
% nrmCnst = inf;

%% main iterations
for k=1:K

    %% threshold parameters is fixed in this implementation
    % different dimension n,m might requier different threshold
    % follow the idea in the reference paper and decrease th every
    % time the optimization problem increases the coherence
    th = 0.05;
    if (k>20)
        th = 0.03;
    end
    if (k>30)
        th = 0.01;
    end
    if (k>40)
        th = 0.01;
    end
    if (k>60)
        th = 0.007;
    end
    if (k>100)
        th = 0.001;
    end

    % connecting the mutual coherence and th
% % %     th = min(mcs)^5;

    %% main optimization problem
    cvx_precision low;
    cvx_solver('sedumi');
    cvx_begin
        variable Anew(n,m);

        cvx_quiet(true);
        minimize (max(max(abs(W.*(Anew'*A))  )) )
        subject to
                norms(Anew-A, nrmCnst, 1) <= th;
    cvx_end

    %% new frame, new mutual coherence
    A = bsxfun(@rdivide, Anew, sqrt(sum(Anew.^2)));
    mc = max(max(abs(A'*A) - eye(m)))

    if (mc < minmc)
        bestA = A;
        minmc = mc;
    end
    
    % keep track of coherences
    mcs = [mcs mc];
end

time = toc;
