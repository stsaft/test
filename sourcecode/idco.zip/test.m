%% IDCO TEST

%% clean-up
close all
clear
clc

%% check if CVX is installed
try
    run('cvx_setup');
catch err
    error('CVX problem.');
end

%% experiment setup
% working dimension
n = 64;
% number of frames
m = 128;
% number of iterations
K = 300;

%% performance limits
umin1 = 1/sqrt(n);
umin2 = sqrt((m-n)/(n*(m-1)));

%% initialization
A = -1 + 2*randn(n, m);
A = bsxfun(@rdivide, A, sqrt(sum(A.^2)));
mcA0 = max(max(abs(A'*A) - eye(m)));

%% improve initialization by SVD
[U S V] = svd(A);
A = U*[eye(n) zeros(n, m-n)]*V';
A = bsxfun(@rdivide, A, sqrt(sum(A.^2)));
mcA = max(max(abs(A'*A) - eye(m)));

%% IDCO call
[B1 mcB1 time1 mcsB1] = idco(A, K);

%% save
save([num2str(n) ' - ' num2str(m)], 'B1', 'umin1', 'umin2', 'mcB1', 'mcA0', 'mcA', 'mcsB1');
