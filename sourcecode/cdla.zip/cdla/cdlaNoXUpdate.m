function [C X error time] = cdlaNoXUpdate(cI, p, C, X)
% A version of C-DLA that does not update the sparse representations.
% It is used by ucdla.

% tic;
[m n] = size(cI);

%% find good starting point
if (nargin < 4)
    [t1 S] = svds(cI, 1);
    C = circulant(t1);
end

if (isempty(C))
    [t1 S] = svds(cI, 1);
    C = circulant(t1);
end

cIF = fft(cI);

%% reduce error
XF = fft(full(X));
thenorms = norms(XF, 2).^2;

sigma = zeros(m,1) + 1i*zeros(m,1);
sigma(1) = thenorms(1)^(-1)*real(XF(1, :))*real(cIF(1, :))';

for j = 2:m/2
      sigma(j) = conj(XF(j,:))*transp(cIF(j,:))/(thenorms(j));
      sigma(m-j+2) = conj(sigma(j));
end

if (mod(m,2) == 0)
  sigma(m/2 + 1) = thenorms(m/2+1)^(-1)*real(XF(m/2+1, :))*real(cIF(m/2+1, :))';
end

sigma = sigma/norm(sigma)*sqrt(m);

%% optimization
c = ifft(sigma);
c = c/norm(c);
C = circulant(c);

C = C(:, 1:p);
X = X(1:p, :);
error = norm(cI-C*X, 'fro');

time = 0;
% time = toc;
