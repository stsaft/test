%% TEST C-DLA

%% clear everything
close all;
clear;
clc;

% the code used omptoolbox, if you have it already comment this line!!!
addpath([pwd '/omptoolbox']);

%% read input data
images = {'barb.bmp'};
Y = readImages(images);
disp('Done!');
[m n] = size(Y);

%% remove the mean
Y = bsxfun(@minus, Y, mean(Y));

%% target sparsity
k0 = 4;

%% call of C-DLA
[C X errorC timeC] = cdla(Y, k0);
