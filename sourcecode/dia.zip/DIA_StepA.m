function [B1 errorold errornew time] = DIA_StepA(Y, B1, k0, K, gamma)
%Step A of the dictionary initialization strategy proposed in
%C. Rusu and B. Dumitrescu, An initialization strategy for
%the dictionary learning problem, IEEE ICASSP, Florence, 2014.
%
% [B1, errrorold, errornew, time_stepa] = DIA_StepA(Y, A, k0, K, gamma);
%
% Input:
%   Y - dataset
%   B1 - the initial, possibly incoherent, initial frame
%   k0 - target sparsity
%   K - number of iterations
%   gamma - the representations of cI in B1, not always necessary
%
% Output:
%   B1 - the trained dictionary
%   errorold - the representation error in the initial frame B1
%   errornew - the representation error in the frained dictionary B1
%   time_stepa - the running time

% start timer
tic;
[n m] = size(B1);

if (n == m)
    theBBT = eye(m);
else
    theBBT = B1'*B1;
end

if (isempty(gamma))
    gamma = omp(B1'*Y, theBBT, k0);
end
totalError = 1;
errorold = norm(Y-B1*gamma, 'fro')/totalError;

for i = 1:K
    if (mod(i, 15)~=0)
        [U S V] = svd(Y*gamma'*B1');
        B1 = U*V'*B1;
    else
        gammasum = sum(abs(gamma), 2);
        S = norm(gamma, 'fro');
        badatoms = find(gammasum <= S/100);
        B1(:, badatoms) = [];
        theBBT = B1'*B1;
    end
            
    gamma = omp(B1'*Y, theBBT, k0);
end

errornew = norm(Y-B1*gamma, 'fro')/totalError;
time = toc;
