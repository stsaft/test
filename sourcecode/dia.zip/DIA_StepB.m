function [B1 errorold errornew gamma time] = DIA_StepB(Y, B1, k0, originalSize)
%Step B of the dictionary initialization strategy proposed in
%C. Rusu and B. Dumitrescu, An initialization strategy for
%the dictionary learning problem, IEEE ICASSP, Florence, 2014.
%
% [B1 errorold errornew gamma time_stepb] = DIA_StepB(cI, B1, k0, originalSize)
%
% Input:
%   Y - dataset
%   B1 - the initial, possibly incoherent, initial frame
%   k0 - target sparsity
%   originalSize - the number of columns in final dictionary
%
% Output:
%   B1 - the trained dictionary
%   errorold - the representation error in the initial frame B1
%   errornew - the representation error in the frained dictionary B1
%   gamma - the representations of Y in B1
%   time_stepb - the running time

% start timer
tic;

[n m] = size(B1);
[n N] = size(Y);
if (n == m)
    theBBT = eye(m);
else
    theBBT = B1'*B1;
end

gamma = omp(B1'*Y, theBBT, k0);
errorold = inf;
errornew = [];

OPTIONS.tol = 1e-4;
while (m < originalSize)
    [U S ~] = svds(Y(:, getWorstReconstructedItems(B1, Y, gamma, 1, floor(0.05*N))), 20, 'L', OPTIONS);
    B1 = [B1 U];
    B1 = B1(:, 1:min(originalSize, end));
    theBBT = B1'*B1;

    [n m] = size(B1);
    
    gamma = omp(B1'*Y, theBBT, k0);
    
    [n m] = size(B1);
end

if (isempty(errornew))
    errornew = norm(Y - B1*gamma, 'fro')/norm(Y, 'fro');
end

time = toc;
