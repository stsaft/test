%% TEST DIA

%% clean-up
close all;
clear;
clc;

% the code used omptoolbox, if you have it already comment this line!!!
addpath([pwd '/omptoolbox']);

%% read input data
images = {'lena512.bmp', 'peppers.bmp'};
Y = readImages(images);

% normalize
Y = Y./255;
% Y = bsxfun(@rdivide, Y, sqrt(sum(Y.^2)));
[n N] = size(Y);
disp('Done reading!');

%% parameters
n = 64;
k0 = 4;
iterNum = 100;
dictSize = 128;

%% AK-SVD
A = rand(n, dictSize);
% A = odctdict(n, dictSize);
A = bsxfun(@rdivide, A, sqrt(sum(A.^2)));
[A_old gamma_old error_old] = myksvdApproximate(Y, dictSize, k0, iterNum, A, [], []);

%% DIA
[A R] = qr(rand(64));
[A, ~, ~, time_stepa] = DIA_StepA(Y, A, k0, iterNum/2, []);
[A, ~, ~, ~, time_stepb] = DIA_StepB(Y, A, k0, dictSize);

%% DIA + AK-SVD
[A gamma error] = myksvdApproximate(Y, dictSize, k0, iterNum, A, [], []);

%% SK-SVD
% % % H = 3;
% % % R = 3;
% % % [A_sksvd gamma_sksvd time_sksvd error_sksvd] = SKSVD(Y, k0, dictSize, H, R, -inf);

%% reconstruction
% % % RMSE_sksvd = sqrt( mean( (Y(:) - vec(A_sksvd*gamma_sksvd)).^2 ) );
RMSE_old = sqrt( mean( (Y(:) - vec(A_old*gamma_old)).^2 ) )
RMSE_new = sqrt( mean( (Y(:) - vec(A*gamma)).^2 ) )
