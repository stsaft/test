function [bestA bestgamma myerrors k] = myksvdApproximate(Y, dictSize, k0, maxIter, A, minerror, gamma)
[m, N] = size(Y);
A = A(:, 1:dictSize);

if (isempty(gamma))
    gamma = omp(A'*Y, A'*A, k0);
end
totalError = 1;
error = norm(Y-A*gamma, 'fro')/totalError;
besterror = inf;
bestA = A;
Js = zeros(1, dictSize);

k = 0;
index = 0;
myerrors = [];

while(1)    
    k = k + 1;
    
% % %     p = randperm(dictSize);
    p = 1:dictSize;
    
    for j = 1:dictSize
        j0 = p(j);
        
        J = find(gamma(j0,:));
        Js(j0) = length(J);
        
        if (length(J)<1)
% % %             x = rand(m,1);
% % %             x = x/norm(x);
% % %             A(:, j0) = x;
            dataindex = getWorstReconstructedItems(A, Y, gamma, 1, 1);
            A(:, j0) = Y(:, dataindex) / norm(Y(:, dataindex));
            continue;
        end

        support = setdiff(1:dictSize, j0);
        M = A(:, support)*gamma(support, J);
        U = Y(:, J)*gamma(j0, J)' - M*gamma(j0, J)';
        U = U/norm(U);

        A(:, j0) = U;
        gamma(j0, J) = Y(:, J)'*U - M'*U;
    end
    
    gamma = omp(A'*Y, A'*A, k0);
    olderror = error;
    error = norm(Y-A*gamma, 'fro')/totalError;
    
    index = index + 1;
    myerrors(index) = error;
    
    if (besterror>error)
        bestA = A;
        besterror = error;
        bestgamma = gamma;
    end
    
    if (error <= minerror)
        break;
    end
    
    if (k == maxIter)
        break;
    end
end

% myerrors(index+1) = norm(Y-bestA*bestgamma, 'fro')/totalError;
myerrors = norm(Y-bestA*bestgamma, 'fro');
